import NAMEPACK as mp
import NAMEPACK.subpack1 as ms
import NAMEPACK.subpack2 as ms1
from NAMEPACK.subpack1 import oper as ar
from NAMEPACK.subpack2 import oper2 as ar1
print(mp.main)
print(mp.mainpackdemo())
print(ms.sub)
print(ms.subpackdemo1())
print(ms1.sub)
print(ms1.subpackdemo2())
print(ar.divide(9))
print(ar.multiply(5))
print(ar1.addition(5))
print(ar1.subtraction(8))