def multiply(a):
    return (a*3)
def divide(a):
    return (a/3)
