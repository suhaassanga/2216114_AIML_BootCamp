def addition(a):
    return a+3
def subtraction(a):
    return a-3