import MAINPACK as mp
import MAINPACK.subpack1 as ms1
import MAINPACK.subpack2 as ms2
from MAINPACK.subpack1 import addsub as a1
from MAINPACK.subpack2 import muldiv as a2
print(mp.main)
print(mp.mainpackdemo())

print(ms1.sub)
print(ms1.subpackdemo1())
print(ms2.sub)
print(ms2.subpackdemo2())

print(a1.add(4,5))
print(a1.sub(10,5))
print(a2.mul(10,5))
print(a2.div(10,5))